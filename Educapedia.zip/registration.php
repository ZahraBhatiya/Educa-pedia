<?php
  include('connection.php');
  if(isset($_POST["btn"]))
  {
	$fname= $_POST["fname"];
    $lname= $_POST["lname"];
	$email = $_POST["email"];
    $pass= $_POST["password"];
    $city= $_POST["city"];
	$state= $_POST["state"];
    $country= $_POST["country"];
	$birth= $_POST["birthdate"];
	$course = $_POST["course"];
    $college = $_POST["college"];
    $university = $_POST["university"];
    $graduation = $_POST["graduation"];

	$query="insert into registration (first_name, last_name, email, user_password, city, state, country, birthdate, course, college, university, graduation) values(?,?,?,?,?,?,?,?,?,?,?,?)";
	$stmt=$con->prepare($query);
	$stmt->bind_param("sssssssssssi", $fname, $lname, $email, $pass, $city, $state, $country, $birth, $course, $college, $university, $graduation);
	$stmt->execute();

	if($stmt->affected_rows>0)
	{
		echo '<script> alert("Registration is successfuly compeleted. You can login now")</script>';
	}
	else{
		echo '<script>alert("Registration is not successfuly compeleted.")</script>';
	}
	$con->close();
  }
?>