<?php
   $host="localhost";
   $user="root";
   $pass="";
   $dbname ="users_info";

   $con=mysqli_connect($host, $user, $pass, $dbname);
   if(mysqli_connect_error()>0)
   {
       die("Failed to connect with MySQL: ". mysqli_connect_error());
   }
  
?>