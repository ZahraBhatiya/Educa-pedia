if(isset($_POST["btn"]))
  {
	$name= $_POST["name"];
	$email = $_POST["email"];
	$mob= $_POST["mobile"];
	$subject= $_POST["subject"];
	$message = $_POST["message"];

	$query="insert into contact (person_name, person_email, person_mobile, subject, message) values(?,?,?,?,?)";
	$stmt=$con->prepare($query);
	$stmt->bind_param("sssss", $name, $email, $mob, $subject, $message);
	$stmt->execute();

	if($stmt->affected_rows>0)
	{
		echo "Your message is sent.";
	}
	else{
		echo "Your message is not sent.";
	}
	$con->close();
  }
?>