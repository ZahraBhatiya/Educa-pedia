<?php
  include('connection.php');
  $msg="";
  if(isset($_POST['email'])){
	  
	  $email=mysqli_real_escape_string($con,$_POST['email']);
    $pass="select user_password from registration where email='$email' ";
	
	  $stmt=mysqli_query($con,$pass);
	  $row=mysqli_fetch_array($stmt, MYSQLI_ASSOC);
	  $count=mysqli_num_rows($stmt);

	  if($count==1)
	  {
		$password=$row["user_password"];
		
	  }
	  $msg="Mail has sent to your email id";
	  
	  $html="<p>Your email and password is:</p><table><tr><td>Email</td><td>$email</td></tr><tr><td>Password</td><td>$password</td></tr></table>";
	  
	  include('smtp/PHPMailerAutoload.php');
	  $mail=new PHPMailer(true);
	  $mail->isSMTP();
	  $mail->Host="smtp.gmail.com";
	  $mail->Port=587;
	  $mail->SMTPSecure="tls";
	  $mail->SMTPAuth=true;
	  $mail->Username="educapediastuff@gmail.com";
	  $mail->Password="Fm@Zb@Td@Ar#123";
	  $mail->SetFrom("educapediastuff@gmail.com");
	  $mail->addAddress($email);
	  $mail->IsHTML(true);
	  $mail->Subject="Password Recovery";
	  $mail->Body=$html;
	  $mail->SMTPOptions=array('ssl'=>array(
		  'verify_peer'=>false,
		  'verify_peer_name'=>false,
		  'allow_self_signed'=>false
	  ));
	  
	  echo $msg;
  }
  ?>