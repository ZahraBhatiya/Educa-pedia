<?php
  include('connection.php');
  if(isset($_POST["btn"]))
  {
    $email = $_POST["email"];
    $pass= $_POST["password"];

	$query="select course from registration where email='$email' and user_password='$pass'";
	//$stmt=$con->prepare($query);
    $stmt=mysqli_query($con, $query);
	$row=mysqli_fetch_array($stmt, MYSQLI_ASSOC);

    $count=mysqli_num_rows($stmt);

	if($count==1)
	{
        $course=$row["course"];
        if($course=="Electronics and Communication")
        {
            header("location:ece.html");
        }
        else if($course=="Civil")
        {
            header("location:civil.html");
        }
        else if($course=="Mechanical")
        {
            header("location:me.html");
        }
        else if($course=="Computer")
        {
            header("location:ce.html");
        }
        else if($course=="Electrical")
        {
            header("location:electrical.html");
        }
        else
        {
            header("location:index.html");
            echo "Course not found";
        }
		
	}
	else{
		echo "Invalid username and password";
	}

  }
?>